public class Main {
    public static void main(String[] args) {
        AnimationFrame frame = new AnimationFrame();
    }
}