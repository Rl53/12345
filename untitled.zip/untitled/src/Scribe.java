
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Scribe extends TimerTask {
    public void run(){

    }
}
