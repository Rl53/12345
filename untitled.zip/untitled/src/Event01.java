public class Event01 {
    GameManager g;
    public Event01(GameManager g) {
        this.g = g;

    }

    public void attack() {

    }
}
